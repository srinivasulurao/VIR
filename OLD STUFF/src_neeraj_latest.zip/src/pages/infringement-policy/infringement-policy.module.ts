import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InfringementPolicyPage } from './infringement-policy';

@NgModule({
  declarations: [
    InfringementPolicyPage,
  ],
  imports: [
    IonicPageModule.forChild(InfringementPolicyPage),
  ],
})
export class InfringementPolicyPageModule {}
