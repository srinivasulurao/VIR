import { Api } from './api/api';
//import { Settings } from './settings/settings';
//import { User } from './user/user';
import { VirProvider } from './vir/vir';

export {
    Api,
    VirProvider
    //Settings,
    //User
};
