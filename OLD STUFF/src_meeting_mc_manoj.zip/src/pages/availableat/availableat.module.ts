import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AvailableatPage } from './availableat';

@NgModule({
  declarations: [
    AvailableatPage,
  ],
  imports: [
    IonicPageModule.forChild(AvailableatPage),
  ],
})
export class AvailableatPageModule {}
