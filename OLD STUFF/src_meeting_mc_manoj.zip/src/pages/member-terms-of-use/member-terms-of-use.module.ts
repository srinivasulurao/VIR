import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MemberTermsOfUsePage } from './member-terms-of-use';

@NgModule({
  declarations: [
    MemberTermsOfUsePage,
  ],
  imports: [
    IonicPageModule.forChild(MemberTermsOfUsePage),
  ],
})
export class MemberTermsOfUsePageModule {}
