import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OnlineBuyPage } from './online-buy';

@NgModule({
  declarations: [
    OnlineBuyPage,
  ],
  imports: [
    IonicPageModule.forChild(OnlineBuyPage),
  ],
})
export class OnlineBuyPageModule {}
