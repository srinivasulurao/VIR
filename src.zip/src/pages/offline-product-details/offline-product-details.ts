import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,AlertController } from 'ionic-angular';


/**
 * Generated class for the OfflineProductDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-offline-product-details',
  templateUrl: 'offline-product-details.html',
})
export class OfflineProductDetailsPage {
  public offlineProduct:any;
  public product_main_image:any;
  prd_image:any;
  showDiv:any;
  imageClass:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,public alertCtrl: AlertController) {
    //this.imageClass =  document.querySelector('.content .prdImage');
    //this.showDiv = document.querySelector('.content #prd0');

    this.offlineProduct=this.navParams.get('product_details');
    this.product_main_image=this.offlineProduct.mainimage;
    this.prd_image=this.offlineProduct.images;
  }


  getProductDetail(){


  }

  ionViewWillEnter() {
    /*this.imageClass.style.display = 'none';
    this.showDiv.style.display = 'flex';*/
  }

  ionViewWillLeave() {
    //this.showDiv.style.display = 'flex';
  }

  selectedImage(id){
    /*this.imageClass.style.display = 'none';
    this.showDiv = document.querySelector('.content #prd'+id);
    this.showDiv.style.display = 'flex';*/
  }

  showAlert(){
    let message="Thank you for showing interest in 'na' Promotion. Your interest has been shared with the concerned Retailer. Kindly visit the store with your VIR Honour Card to avail your exclusive offer. Availability of product would be on first cum first serve basis and no guarantee of the availability is assured. However you can call the store and confirm the product's availability before visiting the store.Contact No : 0123456789";
    let alert = this.alertCtrl.create({
      title: 'I am Intrested',
      subTitle: message,
      buttons: ['Dismiss']
    });
    alert.present();
  }

}
